﻿using System;
namespace GXPEngine
{
    public class EmptyClass
    {
        public EmptyClass()
        {
        }
    }
}
